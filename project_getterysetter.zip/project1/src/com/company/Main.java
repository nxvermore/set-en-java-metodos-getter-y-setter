package com.company;

public class Main {

    public static void main(String[] args){
    Persona persona = new Persona();
    persona.setEdad(31);
    persona.setNombre("Federico");
    persona.setTelefono(586364823);
    System.out.println(persona.getNombre());
        System.out.println(persona.getEdad());
        System.out.println(persona.getTelefono());

    }
}

//esto siempre fuera de la clase main
class Persona {
    private String nombre;
    private int edad;
    private int telefono;

    //especifico el get y sett para nombre
    public void setNombre(String valor) {
        this.nombre=valor;
    }
    public String getNombre(){
        return this.nombre;
    }
    //especifico el get y sett para edad
    public void setEdad(int valor){
        this.edad=valor;
    }
    public int getEdad(){
        return this.edad;
    }
    //especifico el sett y gett para telefono

    public void setTelefono(int valor) {
        this.telefono=valor;
    }
    public int getTelefono(){
        return this.telefono;
    }
}